
  <!-- footer -->
  <div class="footer">
    <div class="container">
      <div class="row mt-5">
        <div class="col-10 offset-1 col-lg-7  col-md-6 col-sm-7 offset-lg-0 offset-md-0 offset-sm-0">
          <div class="footer_dv">
            <h4 class="footer-blue"> About us</h4>



            <p><span class="text-white">"</span>Aile International School was conceived with the object of provide affordable and quality education and to attend social problems and issues concerning education, skill development, Healthcare facilities to rural and semi urban people. To begin with Sri Bhagwati Foundation , a chartable trust was registered on 3-.09- 2005 , under Indian Trust Act , by an IAS officer Shri KS Singh.<a href="about.php"
                class="about-link footer-blue">Read More</a> <span class="text-white">"</span></p>
          </div>
        </div>

        <div class=" col-10 offset-1 col-lg-2  col-md-3 col-sm-3 offset-lg-0 offset-md-0 offset-sm-0">
          <div class="footer_dv">
            <h4 class="footer-blue">Quick Link</h4>

            <ul>
              <li><a class="foot-font" href="index.php"><i class="icofont-thin-right footerlinks"></i> Home</a></li>
              <li><a class="foot-font" href="about.php"><i class="icofont-thin-right footerlinks"></i>About Us</a></li>
              <li><a class="foot-font" href="gallery.php"><i class="icofont-thin-right footerlinks"></i>
                  Gallery</a></li>
             
              <li><a class="foot-font" href="contact.php"><i class="icofont-thin-right footerlinks"></i>
                  Contact Us</a></li>
            </ul>
          </div>
        </div>

        <div class="col-10 offset-1  col-lg-2 col-md-3 col-sm-3 offset-lg-0 offset-md-0 offset-sm-0">
          <div class="footer_dv">
            <h4 class="footer-blue">Essentials</h4>

            <ul>
              <li><a class="foot-font" href="downloads.php"><i class="icofont-thin-right footerlinks"></i> Download</a></li>
              <li><a class="foot-font" href="smc.php"><i class="icofont-thin-right footerlinks"></i>SMC</a></li>
              <li><a class="foot-font" href="fee.php"><i class="icofont-thin-right footerlinks"></i>
                  Fees</a></li>
             
              <li><a class="foot-font" href="#"><i class="icofont-thin-right footerlinks"></i>
                  Our Guidelines</a></li>
            </ul>
          </div>
        </div>

      </div>
    </div>
  </div>


  <footer class="bg-dark">
    <div id="copyright ">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-9 col-sm-6">
            <p class=" pt-2"><a href="#" style="text-decoration: none;" class="text-white">Designed & Developed by Appex Incode
              </a></p>
          </div>
          <div class="col-md-3 col-sm-6 bg-dark" id="bottom-bar">

            <div class="social-icons ml-auto ">
            
              <a href="#" class="facebook"
                target="_blank"><img alt="FaceBook" src="img/socialmedia/fb.png" width="50" height="50"></a>
              <a href="#" class="instagram" target="_blank"><img alt="Instagram" src="img/socialmedia/it.png" width="50"
                  height="50"></a>
              <a href="#" class="whatsapp" target="_blank"><img
                  alt="whatsapp" src="img/socialmedia/wt.png" width="50" height="50"></a>
              <a href="#" class="youtube" target="_blank"><img
                  alt="You Tube" src="img/socialmedia/yt.png" width="50" height="50"></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>

  </footer>
  <!-- GO TO TOP -->
  <a id="back-to-top" alt="_blank" href="#" class="btn back-to-top" role="button" title="" data-toggle="tooltip"
    data-placement=""><i class="icofont-caret-up"></i></a>
