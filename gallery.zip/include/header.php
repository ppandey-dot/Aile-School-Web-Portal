<!-- Top Bar -->
  <header class="top_section">
    <div id="topbar" class=" d-lg-block d-md-block d-sm-block">
      <div class="container-fluid d-flex">
        <div class=" mr-auto">
          <a class=""><img src="img/logo.png" alt="" class="img-fluid" style="width:72%;"></a>

        </div>

        <div class="social-icons d-none d-lg-block  d-sm-none d-md-block">
          <div class="contacts">
            <div style="padding-bottom:3px;"><i class="icofont-phone" style="position:relative; left:-13px;"></i> <span
                style="position:relative; left:-20px;"><a>+91 8765874610</a></span><br>
            </div>

            <div>
              <i class="icofont-envelope"></i><span><a href="mailto:aileinternational@gmail.com">aileinternational@gmail.com</a>
              </span>
            </div>
          </div>

        
          <a href="#" class="facebook"
            target="_blank"><img alt="FaceBook" src="img/socialmedia/fb.png" width="50" height="50"></a>
          <a href="#" class="instagram" target="_blank"><img alt="Instagram" src="img/socialmedia/it.png" width="50"
              height="50"></a>
          <a href="#" class="whatsapp" target="_blank"><img
              alt="whatsapp" src="img/socialmedia/wt.png" width="50" height="50"></a>
          <a href="https://youtu.be/2ijvYcPK6iI" class="youtube" target="_blank"><img
              alt="You Tube" src="img/socialmedia/yt.png" width="50" height="50"></a>
          <br>



        </div>
        <button class="navbar-toggler collapsed d-lg-none d-md-none" type="button" data-toggle="collapse"
          data-target="#navbarcollapse" aria-controls="#navbarcollapse" aria-expanded="false"
          aria-label="Toggle navigation" style="border:1px solid #014a81; ">
          <i class="icofont-navigation-menu" style="color:#fff; font-size:2.1rem; "></i>
        </button>

      </div>


    </div><!-- EndTop Bar -->

    <nav class="navbar navbar-expand-lg navbar-expand-md navbar-dark mx-background-top-linear  ">
      <a class="navbar-brand text-white" href="#"></a>


      <div class="navbar-collapse collapse" id="navbarcollapse">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>

          <!--<li class="nav-item dropdown">-->
          <!--  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"-->
          <!--    aria-haspopup="true" aria-expanded="false">-->
          <!--    About Us-->
          <!--  </a>-->
          <!--  <div class="dropdown-menu animated slideInDown" aria-labelledby="navbarDropdown">-->
          <!--    <a class="dropdown-item" href="about.php">About Us</a>-->
          <!--    <a class="dropdown-item" href="#">Our Guidelines</a>-->
          <!--  </div>-->
          <!--</li>-->
          <li class="nav-item">
            <a class="nav-link" href="about.php">About US</a>
          </li>
          
        <li class="nav-item">
            <a class="nav-link" href="fee.php">Fee Structure</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="smc.php">SMC</a>
          </li>
          

          <li class="nav-item">
            <a class="nav-link" href="gallery.php">Gallery</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="downloads.php">Download</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Our Guidelines</a>
          </li>

      <li class="nav-item">
            <a class="nav-link" href="contact.php">Contact Us</a>
          </li>

 

        </ul>

      </div>
    </nav>

  </header>